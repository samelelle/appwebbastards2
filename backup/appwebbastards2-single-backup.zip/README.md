# Born Bastards Web App

App React + Vite per gestione Home, Eventi, Rubrica, Riunioni e Foto.

## Avvio Locale

```bash
npm install
npm run dev
```

Su PowerShell su Windows, se compare l'errore su `npm.ps1`, usa:

```powershell
npm.cmd install
npm.cmd run dev
```

Per aprirlo dal telefono sulla stessa rete Wi-Fi, usa l'indirizzo IP del PC che Vite mostra nel terminale, ad esempio `http://192.168.1.3:5173`.
Se serve, l'app è già configurata per ascoltare su tutta la rete locale.

Build produzione:

```bash
npm run build
npm run preview
```

## Dati Condivisi (Supabase)

Le pagine `Eventi` e `Riunioni` supportano sincronizzazione multi-utente con Supabase.
Se le variabili ambiente non sono presenti, l'app usa fallback locale (`localStorage`).

1. Copia `.env.example` in `.env`.
2. Imposta:

```env
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
VITE_DEV_BYPASS_AUTH=true
```

Nota: `VITE_DEV_BYPASS_AUTH` serve solo in sviluppo. Se la imposti su `false`, il login resta attivo anche con `npm run dev`.

3. In Supabase SQL Editor esegui:

```sql
create table if not exists public.events (
	id uuid primary key default gen_random_uuid(),
	title text not null,
	start_at timestamptz not null,
	end_at timestamptz not null,
	note text,
	image text,
	created_at timestamptz not null default now()
);

create table if not exists public.meetings (
	id uuid primary key default gen_random_uuid(),
	data date not null,
	ora text,
	ordine text not null,
	created_at timestamptz not null default now()
);

alter table public.events enable row level security;
alter table public.meetings enable row level security;

create policy "events public read"
on public.events for select
to anon
using (true);

create policy "events public insert"
on public.events for insert
to anon
with check (true);

create policy "events public update"
on public.events for update
to anon
using (true)
with check (true);

create policy "events public delete"
on public.events for delete
to anon
using (true);

create policy "meetings public read"
on public.meetings for select
to anon
using (true);

create policy "meetings public insert"
on public.meetings for insert
to anon
with check (true);

create policy "meetings public update"
on public.meetings for update
to anon
using (true)
with check (true);

create policy "meetings public delete"
on public.meetings for delete
to anon
using (true);
```

Nota: policy aperte per semplicità di avvio. Per produzione reale conviene autenticazione + policy restrittive.
