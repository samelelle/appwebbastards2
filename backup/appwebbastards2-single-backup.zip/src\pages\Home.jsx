import { useEffect } from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import teschioImg from '../assets/teschio1.png';
import MobileBottomNav from '../components/MobileBottomNav';
import useIsMobile from '../hooks/useIsMobile';
import { getUnreadChatCount, getUnreadEventCount, markChatSeen, markEventsSeen, subscribeBadgeChanges } from '../lib/notificationBadges';

function Home({ onLogout, userEmail, isDevMode, canToggleDevMode, onToggleDevMode }) {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [isTabletLandscape, setIsTabletLandscape] = useState(false);
  const [unreadEvents, setUnreadEvents] = useState(null);
  const [unreadChats, setUnreadChats] = useState(null);

  useEffect(() => {
    const updateTabletLandscape = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      setIsTabletLandscape(width > 768 && width <= 1366 && width > height);
    };

    updateTabletLandscape();
    window.addEventListener('resize', updateTabletLandscape);
    window.visualViewport?.addEventListener('resize', updateTabletLandscape);

    return () => {
      window.removeEventListener('resize', updateTabletLandscape);
      window.visualViewport?.removeEventListener('resize', updateTabletLandscape);
    };
  }, []);

  useEffect(() => {
    const refreshUnread = () => {
      setUnreadEvents(getUnreadEventCount());
      setUnreadChats(getUnreadChatCount());
    };

    refreshUnread();
    const timer = window.setInterval(refreshUnread, 5000);
    const unsubscribe = subscribeBadgeChanges(refreshUnread);

    return () => {
      window.clearInterval(timer);
      unsubscribe();
    };
  }, []);

  useEffect(() => {
    const rootEl = document.getElementById('root');
    const prevHtmlOverflow = document.documentElement.style.overflow;
    const prevHtmlOverscroll = document.documentElement.style.overscrollBehavior;
    const prevHtmlTouchAction = document.documentElement.style.touchAction;
    const prevBodyOverflow = document.body.style.overflow;
    const prevBodyOverscroll = document.body.style.overscrollBehavior;
    const prevBodyTouchAction = document.body.style.touchAction;
    const prevRootOverflow = rootEl ? rootEl.style.overflow : '';
    const handleTouchMove = event => event.preventDefault();

    document.documentElement.style.overflow = 'hidden';
    document.documentElement.style.overscrollBehavior = 'none';
    document.documentElement.style.touchAction = 'none';
    const prevOverflow = document.body.style.overflow;
    const prevOverscroll = document.body.style.overscrollBehavior;
    document.body.style.overflow = 'hidden';
    document.body.style.overscrollBehavior = 'none';
    document.body.style.touchAction = 'none';
    if (rootEl) rootEl.style.overflow = 'hidden';
    window.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      window.removeEventListener('touchmove', handleTouchMove);
      document.documentElement.style.overflow = prevHtmlOverflow;
      document.documentElement.style.overscrollBehavior = prevHtmlOverscroll;
      document.documentElement.style.touchAction = prevHtmlTouchAction;
      document.body.style.overflow = prevBodyOverflow || prevOverflow;
      document.body.style.overscrollBehavior = prevBodyOverscroll || prevOverscroll;
      document.body.style.touchAction = prevBodyTouchAction;
      if (rootEl) rootEl.style.overflow = prevRootOverflow;
      document.body.style.overflow = prevOverflow;
      document.body.style.overscrollBehavior = prevOverscroll;
    };
  }, []);

  return (
    <div
      className="bb-page"
      style={{
        height: 'var(--bb-app-height, 100dvh)',
        background: '#111',
        position: 'fixed',
        inset: 0,
        overflow: 'hidden',
        boxSizing: 'border-box',
        touchAction: 'none',
        paddingTop: isMobile ? 'calc(8px + env(safe-area-inset-top))' : 0,
        paddingBottom: isMobile ? 'calc(110px + env(safe-area-inset-bottom))' : 0,
      }}
    >
      <h1
        className="bb-title bb-title-top"
        style={{
          fontSize: isMobile ? '2.55rem' : isTabletLandscape ? '3rem' : '4.8rem',
          marginTop: isTabletLandscape ? '8px' : undefined,
          marginBottom: isTabletLandscape ? '6px' : undefined,
        }}
      >
        BORN BASTARDS
      </h1>
      <div
        style={{
          position: 'absolute',
          top: isMobile ? 'calc(10px + env(safe-area-inset-top))' : '14px',
          right: '12px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          maxWidth: '72vw',
          flexWrap: 'wrap',
          justifyContent: 'flex-end',
        }}
      >
        <span style={{ fontSize: '0.72rem', color: '#ffb366', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {userEmail || ''}
        </span>
        {!isDevMode ? (
          <button
            type="button"
            onClick={onLogout}
            className="bb-add-btn"
            style={{ marginLeft: 0, width: 'auto', height: 'auto', padding: '6px 10px', fontSize: '0.78rem' }}
          >
            Logout
          </button>
        ) : (
          <span style={{ fontSize: '0.72rem', color: '#7ff27f' }}>DEV</span>
        )}
        {canToggleDevMode && (
          <button
            type="button"
            onClick={onToggleDevMode}
            className="bb-add-btn"
            style={{
              marginLeft: 0,
              width: 'auto',
              height: 'auto',
              padding: '6px 10px',
              fontSize: '0.72rem',
              background: isDevMode ? '#0b6b3a' : '#5a3100',
              color: '#fff',
            }}
          >
            DEV BYPASS: {isDevMode ? 'ON' : 'OFF'}
          </button>
        )}
      </div>
      <div
        style={{
          position: isTabletLandscape ? 'absolute' : 'relative',
          top: isTabletLandscape ? 'calc(env(safe-area-inset-top) - 52px)' : 'auto',
          left: isTabletLandscape ? 0 : 'auto',
          right: isTabletLandscape ? 0 : 'auto',
          zIndex: isTabletLandscape ? 2 : 'auto',
          display: 'flex',
          justifyContent: 'center',
          margin: isTabletLandscape ? 0 : '14px 0 0 0',
          pointerEvents: 'none',
        }}
      >
        <img
          src={teschioImg}
          className="bb-hero-img"
          style={isTabletLandscape
            ? {
                width: 'auto',
                height: 'auto',
                maxWidth: '260px',
                maxHeight: '20dvh',
                objectFit: 'contain',
                marginTop: '0',
              }
            : undefined}
        />
      </div>
      {!isMobile && (
        <div
          style={{
            position: 'absolute',
            top: isTabletLandscape
              ? 'calc(env(safe-area-inset-top) + 20dvh - 34px)'
              : 'calc(50% + 140px + 2cm)',
            bottom: isTabletLandscape ? 'calc(88px + env(safe-area-inset-bottom))' : 'auto',
            left: 0,
            width: '100%',
            transform: isTabletLandscape ? 'none' : 'translateY(-50%)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: isTabletLandscape ? '10px' : '24px',
            maxHeight: isTabletLandscape
              ? 'calc(100dvh - (env(safe-area-inset-top) + 20dvh - 34px) - (88px + env(safe-area-inset-bottom)))'
              : 'none',
            overflowY: isTabletLandscape ? 'auto' : 'visible',
            paddingBottom: isTabletLandscape ? '8px' : 0,
          }}
        >
          <button className="bb-event-btn" style={isTabletLandscape ? { width: 'min(72vw, 340px)', minWidth: 'min(72vw, 340px)', fontSize: '1.05rem', padding: '12px 20px' } : undefined} onClick={() => { markEventsSeen(); setUnreadEvents(null); navigate('/eventi'); }}>
            Calendario eventi{Number.isFinite(unreadEvents) && unreadEvents > 0 ? ` (${unreadEvents > 99 ? '99+' : unreadEvents})` : ''}
          </button>
          <button className="bb-event-btn" style={isTabletLandscape ? { width: 'min(72vw, 340px)', minWidth: 'min(72vw, 340px)', fontSize: '1.05rem', padding: '12px 20px' } : undefined} onClick={() => { markChatSeen(); setUnreadChats(null); navigate('/rubrica'); }}>
            Rubrica{Number.isFinite(unreadChats) && unreadChats > 0 ? ` (${unreadChats > 99 ? '99+' : unreadChats})` : ''}
          </button>
          <button className="bb-event-btn" style={isTabletLandscape ? { width: 'min(72vw, 340px)', minWidth: 'min(72vw, 340px)', fontSize: '1.05rem', padding: '12px 20px' } : undefined} onClick={() => navigate('/riunioni')}>Riunioni</button>
          <button className="bb-event-btn" style={isTabletLandscape ? { width: 'min(72vw, 340px)', minWidth: 'min(72vw, 340px)', fontSize: '1.05rem', padding: '12px 20px' } : undefined} onClick={() => navigate('/foto')}>Foto</button>
          <button className="bb-event-btn" style={isTabletLandscape ? { width: 'min(72vw, 340px)', minWidth: 'min(72vw, 340px)', fontSize: '1.05rem', padding: '12px 20px' } : undefined} onClick={() => navigate('/mappa')}>Mappa</button>
        </div>
      )}
      <MobileBottomNav />
    </div>
  );
}

export default Home;
